<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth; 
use Validator;
use Laravel\Sanctum\HasApiTokens;

class LoginController extends Controller
{
    public function login(Request $request){ 
        $login = $request->validate([
            'email' => 'required|string',
            'password' => 'required|string'
        ]);
        if(Auth::attempt($login)){ 
            $user = User::where('email', $request->email)->first();
            if($user){
                if (Hash::check($request->password, $user->password)) {

                    return response()->json(['message' => 'login success']); 
                }
                else {
                    return response()->json(['message' => 'Password mismatch']);
                }
            }
            else{
                return response()->json(['message' => 'User does not exist']);
            }
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised']); 
        } 
        
    }
}
