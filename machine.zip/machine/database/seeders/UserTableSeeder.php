<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Carbon\Carbon;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (!User::where('id', 1)->exists()) {
            $user = new User();
            $user->id = 1;
            $user->name = "Admin";
            $user->email = "admin@admin.com";
            $user->password = bcrypt('password');
            $user->remember_token = "";
            $user->created_at = Carbon::now();
            $user->save();
        }
    }
}
